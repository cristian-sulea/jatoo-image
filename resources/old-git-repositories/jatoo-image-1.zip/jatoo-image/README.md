jatoo-image
===========

A Java Open Source library created to ease the work with images.
