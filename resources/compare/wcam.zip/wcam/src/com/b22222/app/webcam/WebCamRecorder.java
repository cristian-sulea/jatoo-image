package com.b22222.app.webcam;

import java.util.*;
import java.awt.image.BufferedImage;

import com.b22222.util.Util;
import com.b22222.video.ImageProvider;
 
public class WebCamRecorder extends WebCamViewer implements ImageProvider {

	private TimedGrabber grabber;

	public static void main(String[] args) {
		// create a new Recorder and start capturing. see settings.ini for extra details.
		new WebCamRecorder().startTimedCapture();
	}
	
	public WebCamRecorder() {
		super(); // do all the stuff the viewer does. (setting up frame etc...)

		Properties properties = Util.loadProperties();
		String saveLocation = properties.getProperty("saveOutputLocation", "c:\\");
		int delay = Integer.parseInt(properties.getProperty("saveDelay", "1000"));
		
		grabber = new TimedGrabber(this, saveLocation, delay); 
	}

	// this should be called by the instantiating code in order to start the recording
	public void startTimedCapture() {
		grabber.start();
	}
	
	public BufferedImage getImage() {
		return source.getImage();
	}
	
	protected class TimedGrabber extends Thread {
	    
		private ImageProvider provider = null;

		protected String saveLocation; 	// where to save to on disk
		protected int delay;	 		// how long to wait between saves. must not be smaller than 1000
		
	    public TimedGrabber(ImageProvider provider, String saveLocation, int delay) {
	        this.provider = provider;
	        this.delay = (delay < 1000 ? 1000 : delay); // otherwise would have filename problems...
	    }
		
		public void setDelay(int delay) {
			this.delay = delay;
		}
	    
	    public void run() {
	        while (provider != null) {
	        	Util.saveJPG(provider.getImage(), saveLocation + Util.getTimeStamp() + ".jpg");
	            try {
	                sleep(delay);
	            } catch (InterruptedException ie) {
	                ie.printStackTrace();
	            }
	        }
	    }
	}
	
}
