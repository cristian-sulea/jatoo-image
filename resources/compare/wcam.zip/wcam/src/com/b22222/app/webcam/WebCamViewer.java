package com.b22222.app.webcam;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

import com.b22222.util.Util;
import com.b22222.video.VideoPanel;
import com.b22222.video.VideoSource;
 
public class WebCamViewer {

    private static final long serialVersionUID = 55318008;

    protected VideoSource source = null;
	protected VideoPanel panel = null;

	protected JButton button;

	public static void main(String[] args) {
		new WebCamViewer();
	}
	
	public WebCamViewer() {
		Properties properties = Util.loadProperties();
		String deviceLocation = properties.getProperty("videoSource", "vfw:Microsoft WDM Image Capture (Win32):0");

		source = new VideoSource(deviceLocation);
		panel = new VideoPanel(source);
		
		Frame f = new Frame("WCam");
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				source.close();
				System.exit(0);
			}
		});
		button = new JButton("Save Image");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Util.saveJPG(source.getFrame(), "c:\\work\\pat\\wcam\\cam.jpg");
			}
		});
		
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.add(panel,BorderLayout.CENTER);
		p.add(button,BorderLayout.SOUTH);
		
		f.add("Center", p);
		f.pack();
		f.setSize(new Dimension(320,300));
		f.setVisible(true);
	}
	
	public void setCaptureButtonVisible(boolean flag) {
		button.setVisible(flag);
	}
 
}
