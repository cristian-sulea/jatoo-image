package com.b22222.app.webcam;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.util.Properties;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

import javax.swing.JButton;
import javax.swing.JPanel;

import org.joone.helpers.factory.JooneTools;
import org.joone.net.NeuralNet;

import com.b22222.routine.Comparer;
import com.b22222.routine.Comparison;
import com.b22222.routine.EdgeDetector;
import com.b22222.util.Util;
import com.b22222.video.ImageProvider;
import com.b22222.video.VideoPanel;
import com.b22222.video.VideoSource;

public class WebCamMouseNetTest implements ImageProvider {
	
    protected VideoSource source = null;
	protected VideoPanel panel = null;

	private Tester tester;
	JButton button;

	String mousePositionNetworkTest;

	public static void main(String[] args) {
		new WebCamMouseNetTest();
	}
	
	public WebCamMouseNetTest() {
		tester = new Tester(this);

		Properties properties = Util.loadProperties();
		String deviceLocation = properties.getProperty("videoSource", "vfw:Microsoft WDM Image Capture (Win32):0");
		mousePositionNetworkTest = properties.getProperty("mousePositionNetworkTest", "c:\\mouse_neural.net");

		source = new VideoSource(deviceLocation);
		panel = new VideoPanel(source);
		
		Frame f = new Frame("WebCam Mouse Trainer");
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				source.close();
				System.exit(0);
			}
		});
		JButton neut = new JButton("Neutral State");
		neut.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tester.neutral();
			}
		});
		
		button = new JButton("Test Case");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				tester.test();
			}
		});
		
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.add(panel,BorderLayout.CENTER);
		p.add(neut,BorderLayout.NORTH);
		p.add(button,BorderLayout.SOUTH);
		
		f.add("Center", p);
		f.pack();
		f.setSize(new Dimension(640,440));
		f.setVisible(true);

	}
	
	public BufferedImage getImage() {
		return source.getImage();
	}
	
	protected class Tester extends Thread {
	    
		private ImageProvider provider = null;

	    // used for scaling our images
		int imageScaleX;	
		int imageScaleY;	
		
		// Cache/buffer for two helpfull images
		BufferedImage lastImage;
		BufferedImage thisImage;
		
		// Cache/buffer for two helpfull states
		com.b22222.routine.State lastState;
		com.b22222.routine.State thisState;
		
		// used for comparing our State's
		Comparer comparer;
		
		// used for finding edges
		EdgeDetector edgeDetector;
		double edgeCleanupSD, edgeCleanupAvg, edgeCleanupBase;
		
		// trainer specific
		protected int gridY;
		protected int gridX;
		
		NeuralNet net;

		
	    public Tester(ImageProvider provider) {
			Properties properties = Util.loadProperties();
			gridX = Integer.parseInt(properties.getProperty("mouseTrainerGridX", "16"));
			gridY = Integer.parseInt(properties.getProperty("mouseTrainerGridY", "12"));

			imageScaleX = Integer.parseInt(properties.getProperty("imageScaleX", "1"));
			imageScaleY = Integer.parseInt(properties.getProperty("imageScaleY", "1"));

			int imageCompareX = Integer.parseInt(properties.getProperty("imageCompareX", "31"));
			int imageCompareY = Integer.parseInt(properties.getProperty("imageCompareY", "23"));
			int imageCompareLeniency = Integer.parseInt(properties.getProperty("imageCompareLeniency", "10"));

			double edgeDetectFlatten = Double.parseDouble(properties.getProperty("edgeDetectFlatten", "-0.1667"));
			double edgeDetectCeling = Double.parseDouble(properties.getProperty("edgeDetectCeling", "0.3333"));

			// setup our comparer for later use.
			comparer = new Comparer(imageCompareX, imageCompareY, imageCompareLeniency);

	 		// setup our edgedetector for later use.
			edgeDetector = new EdgeDetector(edgeDetectFlatten, edgeDetectCeling);

			edgeCleanupSD = Double.parseDouble(properties.getProperty("edgeCleanupSD", "0.5"));
			edgeCleanupAvg = Double.parseDouble(properties.getProperty("edgeCleanupAvg", "1"));
			edgeCleanupBase = Double.parseDouble(properties.getProperty("edgeCleanupBase", "0"));
			
			this.provider = provider;
			
			// now setup the neural network
	        try {
	            // Create the network: 3 layers with a logistic output layer
                net = JooneTools.load(properties.getProperty("mousePositionNetworkOut", "c:\\mouse_neural.net"));
                net.getMonitor().setSingleThreadMode(true);
            } catch (Exception exc) {
            	exc.printStackTrace();
            }
			
	    }
	    
	    public void neutral() {
			System.out.println("Taking neutral picture...");
			lastImage = provider.getImage();
			lastState = new com.b22222.routine.State(lastImage, imageScaleX, imageScaleY); 
	    }
		
		public void test() {
			java.awt.GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
			int screenHeight = gd.getDisplayMode().getHeight();
			int screenWidth = gd.getDisplayMode().getWidth();
			
			// size of the regions on the screen.
			int by = (int)(screenHeight / gridY);
			int bx = (int)(screenWidth / gridX);
			
			// snap picture
			thisImage = provider.getImage();
			thisState = new com.b22222.routine.State(thisImage, imageScaleX, imageScaleY); 
			
			
    		// compare the states and get a variance map
    		Comparison comparison = comparer.compare(lastState, thisState);
			// return a map with the edges emphasized
			int[][] edge = edgeDetector.process(comparison.getVariance());
			
			// now we try clean up some noise out of the map.
			int average = Util.intArrayAvgNonZero(edge);
			int stdDev = Util.intArrayStdDev(edge);
			int edgeCleanupThreshold = (int)(edgeCleanupBase+((average*edgeCleanupAvg) + (stdDev*edgeCleanupSD)));

			// first lets zero fill any map values that dont cross a certain threshold
			edge = Util.intArrayZeroFillUnderThreshold(edge, edgeCleanupThreshold, 1);
			edge = Util.intArrayRemoveNeighbourless(edge);
			//Util.outputIntArray(edge);

			Graphics2D g = thisImage.createGraphics();
			Util.renderIntArrayToGraphicsDevice(edge, thisImage.getWidth(), thisImage.getHeight(), g);
			Util.renderIntArrayStatsToGraphicsDevice(edge, g);
	    	Util.saveJPG(thisImage, mousePositionNetworkTest + "test.jpg");
			
            // Interrogate the neural network and prints the results
			double[] input = new double[edge.length * edge[0].length];
        	for (int q = 0, e = 0; q < edge.length; q++)
        		for (int w = 0; w < edge[0].length; w++)
        			input[e++] = edge[q][w];
			double[] output = JooneTools.interrogate(net, input);
			System.out.println("Output: " + output[0] + ", " + output[1]);

			// Test the network and prints the rmse
		
            //double testRMSE = JooneTools.test(net, inputArray, desiredArray);
            //System.out.println("\nTest error = "+testRMSE);
			
		}
		
		
	}
	

	
}


