package com.b22222.app;

import java.util.*;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

import com.b22222.routine.Comparer;
import com.b22222.routine.Comparison;
import com.b22222.routine.EdgeDetector;
import com.b22222.routine.State;
import com.b22222.util.Util;

/* 
 * App that is used to display information. Usefull for calibrating a settings file - Otherwise just interesting.
 */
public class ImageCompareState {

	// used for scaling our images
	int imageScaleX;	
	int imageScaleY;	
	
	// Cache/buffer for two helpfull images
	BufferedImage lastImage;
	BufferedImage thisImage;
	
	// Cache/buffer for two helpfull states
	State lastState;
	State thisState;
	
	// used for comparing our State's
	Comparer comparer;
	
	// used for finding edges
	EdgeDetector edgeDetector;
	double edgeCleanupSD, edgeCleanupAvg, edgeCleanupBase;
	
	
	public static void main(String[] args) {
		// start profiling
		Date d1 = new Date(); 
		
		// do the work
		new ImageCompareState().compare("c:\\work\\pat\\wcam\\man1.jpg", "c:\\work\\pat\\wcam\\man2.jpg", "c:\\work\\pat\\wcam\\output.jpg");
		
		// end profiling
		Date d2 = new Date(); 
		long t = d2.getTime() - d1.getTime();
		System.out.println("Time: " + t + "ms   ("+(1000/t)+" ~fps)");
	}
	
	public ImageCompareState() {
		Properties properties = Util.loadProperties();
		imageScaleX = Integer.parseInt(properties.getProperty("imageScaleX", "1"));
		imageScaleY = Integer.parseInt(properties.getProperty("imageScaleY", "1"));

		int imageCompareX = Integer.parseInt(properties.getProperty("imageCompareX", "160"));
		int imageCompareY = Integer.parseInt(properties.getProperty("imageCompareY", "120"));
		int imageCompareLeniency = Integer.parseInt(properties.getProperty("imageCompareLeniency", "10"));

		double edgeDetectFlatten = Double.parseDouble(properties.getProperty("edgeDetectFlatten", "-0.1667"));
		double edgeDetectCeling = Double.parseDouble(properties.getProperty("edgeDetectCeling", "0.3333"));

		edgeCleanupSD = Double.parseDouble(properties.getProperty("edgeCleanupSD", "0.5"));
		edgeCleanupAvg = Double.parseDouble(properties.getProperty("edgeCleanupAvg", "1"));
		edgeCleanupBase = Double.parseDouble(properties.getProperty("edgeCleanupBase", "0"));
		
		// setup our comparer for later use.
		comparer = new Comparer(imageCompareX, imageCompareY, imageCompareLeniency);

 		// setup our edgedetector for later use.
		edgeDetector = new EdgeDetector(edgeDetectFlatten, edgeDetectCeling);
	}
	
	public void compare(String file1, String file2, String outputFile) {
		lastImage = Util.imageToBufferedImage(Util.loadJPG(file1)); 
		lastState = new State(lastImage, imageScaleX, imageScaleY); 

		thisImage = Util.imageToBufferedImage(Util.loadJPG(file2)); 
		thisState = new State(thisImage, imageScaleX, imageScaleY); 
		
		// compare the states and get a variance map
		Comparison comparison = comparer.compare(lastState, thisState);
		// return a map with the edges emphasized
		int[][] edge = edgeDetector.process(comparison.getVariance());
		
		// now we try clean up some noise out of the map.
		int average = Util.intArrayAvgNonZero(edge);
		int stdDev = Util.intArrayStdDev(edge);
		int edgeCleanupThreshold = (int)(edgeCleanupBase+((average*edgeCleanupAvg) + (stdDev*edgeCleanupSD)));

		// first lets zero fill any map values that dont cross a certain threshold
		edge = Util.intArrayZeroFillUnderThreshold(edge, edgeCleanupThreshold, 1);
		edge = Util.intArrayRemoveNeighbourless(edge);
		//Util.outputIntArray(edge);
		
		Graphics2D g = thisImage.createGraphics();
		Util.renderIntArrayToGraphicsDevice(edge, thisImage.getWidth(), thisImage.getHeight(), g);
		Util.renderIntArrayStatsToGraphicsDevice(edge, g);
    	Util.saveJPG(thisImage, outputFile);
	}
	
	
	
	
	
}
