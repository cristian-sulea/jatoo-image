package com.b22222.app.webcam;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

import org.joone.engine.*;
import org.joone.engine.learning.*;
import org.joone.helpers.factory.JooneTools;
import org.joone.io.*;
import org.joone.net.*;
import com.b22222.io.*;

import com.b22222.util.Util;

public class WebCamMouseLearner implements NeuralNetListener {
	
	NeuralNet net;
	String mousePositionNetworkIn;
	String mousePositionNetworkOut;
	
	public static void main(String[] args) {
		new WebCamMouseLearner().learn();
	}
	
	public WebCamMouseLearner() {
		
	}
	
	public void learn() {
		// load properties
		Properties properties = Util.loadProperties();
		String mouseLearnerInput = properties.getProperty("mouseLearnerInput", "input");
		mousePositionNetworkIn = properties.getProperty("mousePositionNetworkIn", "c:\\mouse_neural.net");
		mousePositionNetworkOut = properties.getProperty("mousePositionNetworkOut", "c:\\mouse_neural.net");
		int imageCompareX = Integer.parseInt(properties.getProperty("imageCompareX", "31"));
		int imageCompareY = Integer.parseInt(properties.getProperty("imageCompareY", "23"));
		String mouseTrainerOutput = properties.getProperty("mouseTrainerOutput", "c:\\mouse_output\\");
		
		// load training material
		int length = 0;
        try {
            File inputFile = new File(mouseTrainerOutput + mouseLearnerInput);
            File[] files = inputFile.listFiles();
	        for (int i = 0; i < files.length; i++) {
	        	if (files[i].getName().indexOf(".txt") > -1)
	        		length++;
	        }
        } catch (Exception e) { e.printStackTrace(); }
		
		double[][] t = new double[length][imageCompareX*imageCompareY+2]; // two for coord results
        try {
            File inputFile = new File(mouseTrainerOutput + mouseLearnerInput);
            File[] files = inputFile.listFiles();
            int j = 0;
	        for (int i = 0; i < files.length; i++) {
	        	// for every text data file in the directory loads its data onto a new row in the content string.
	        	if (files[i].getName().indexOf(".txt") > -1) {
	            	int[][] m = Util.sillyRetrieveIntArray(Util.readTextFromFile(files[i].getCanonicalPath()).trim(), imageCompareX, imageCompareY);
	            	for (int q = 0, e = 0; q < imageCompareY; q++)
	            		for (int w = 0; w < imageCompareX; w++)
	            			t[j][e++] = m[q][w];
	            	String n = files[i].getName();
	            	t[j][t[0].length - 2] = Double.parseDouble(n.substring(0, n.indexOf("_"))); // set x
	            	t[j][t[0].length - 1] = Double.parseDouble(n.substring(n.indexOf("_")+1,n.indexOf("."))); // set y
	            	j++;
	        	}
	        }
        } catch (Exception e) {
        	e.printStackTrace();
        }
    	for (int i = 0; i < t.length; i++) {
    		for (int j = 0; j < t[0].length; j++) {
    			System.out.print(t[i][j] + ",");
    		}
    		System.out.println("");
    	}
    			
        MemoryInputSynapse inputStream = new MemoryInputSynapse();
        inputStream.setInputArray(t);
        inputStream.setAdvancedColumnSelector("1-" + t[0].length);
        //inputStream.addPlugIn(new ShufflePlugin());
        
		
	
		// create neural network
        LinearLayer input = new LinearLayer();
        SigmoidLayer hidden = new SigmoidLayer();
        SigmoidLayer output = new SigmoidLayer();
	        input.setLayerName("input");
	        hidden.setLayerName("hidden");
	        output.setLayerName("output");
	        // sets their dimensions
	        input.setRows(713);		// number of weights in img. [x*y]
	        hidden.setRows(713);
	        output.setRows(2);			// want to map the weights to an 'x' an a 'y'
        
        // Now create the two Synapses
        FullSynapse synapse_IH = new FullSynapse(); // input -> hidden conn.
        FullSynapse synapse_HO = new FullSynapse(); // hidden -> output conn.
	        synapse_IH.setName("IH");
	        synapse_HO.setName("HO");

        // Connect the input layer with the hidden layer
        input.addOutputSynapse(synapse_IH);
        hidden.addInputSynapse(synapse_IH);

        // Connect the hidden layer with the output layer
        hidden.addOutputSynapse(synapse_HO);
        output.addInputSynapse(synapse_HO);
        
        
        // The first InputConnector containing the training data
        InputConnector input1 = new InputConnector();
	        input1.setInputSynapse(inputStream);
	        input1.setAdvancedColumnSelector("1-" + (t[0].length - 2));
	        input1.setBuffered(true); // By default it's false
	        input.addInputSynapse(input1);

		// The second InputConnector containing the desired data
		InputConnector input2 = new InputConnector();
			input2.setInputSynapse(inputStream);
			input2.setAdvancedColumnSelector("" + (t[0].length - 1) + "," + (t[0].length));
			input2.setBuffered(true); // By default it's false
			TeachingSynapse trainer = new TeachingSynapse();
			trainer.setDesired(input2);
		
			// Creates the error output file
			FileOutputSynapse error = new FileOutputSynapse();
			error.setFileName(mouseTrainerOutput + mouseLearnerInput + "\\learn_output.log");
			//error.setBuffered(false);
			trainer.addResultSynapse(error);
			output.addOutputSynapse(trainer);
		
		// Now the machine
		if (mousePositionNetworkIn.trim().equals("")) {
			net = new NeuralNet();
			net.addLayer(input, NeuralNet.INPUT_LAYER);
			net.addLayer(hidden, NeuralNet.HIDDEN_LAYER);
			net.addLayer(output, NeuralNet.OUTPUT_LAYER);
			net.setTeacher(trainer);
			
			System.out.println("New net created.");
		} else {
			try {
				net = JooneTools.load(mousePositionNetworkIn);
			} catch (Exception e) { e.printStackTrace(); }
			System.out.println("Net loaded from file.");
		}
		// Gets the Monitor object and set the learning parameters
		Monitor monitor = net.getMonitor();
		monitor.setLearningRate(0.8);
		monitor.setMomentum(0.3);
		
		// The application registers itself as monitor's listener so it can receive the notifications of termination from the net. 
		monitor.addNeuralNetListener(this);
		
		
		// train network
		monitor.setTrainingPatterns(450); // # of rows (patterns) contained in the input file
		monitor.setTotCicles(1); // How many times the net must be trained on the input patterns
		monitor.setLearning(true); // The net must be trained
		net.go(); // The net starts the training job

		System.out.println("Learning initiated...");
	}
	
    public void cicleTerminated(NeuralNetEvent e) {
    }
    
    public void errorChanged(NeuralNetEvent e) {
        Monitor mon = (Monitor) e.getSource();
        long	c = mon.getCurrentCicle();
        
        // We want to print the results every 200 cycles
        if (c % 8 == 0) {
            System.out.println(c + " epochs remaining - RMSE = " + mon.getGlobalError());
        }
    }
    
    public void netStarted(NeuralNetEvent e) {
        System.out.println("Started...");
    }
    
    public void netStopped(NeuralNetEvent e) {
        System.out.println("Complete Training...");
        Monitor mon = (Monitor) e.getSource();
        long c = mon.getCurrentCicle();
        System.out.println("RMSE = " + mon.getGlobalError());
		
        // persist network to machine file
        try {
        	JooneTools.save(net, mousePositionNetworkOut);
        } catch (Exception ex) { ex.printStackTrace(); }
        System.out.println("Wrote new NeuralNet to: " + mousePositionNetworkOut);
        
        
    }
    
    public void netStoppedError(NeuralNetEvent e, String error) {
        System.out.println("Error: "+error);
        System.exit(1);
    }
    
	
}


