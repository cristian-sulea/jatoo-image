package com.b22222.app.webcam;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.util.Properties;
import java.awt.Robot;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JPanel;

import com.b22222.routine.Comparer;
import com.b22222.routine.Comparison;
import com.b22222.routine.EdgeDetector;
import com.b22222.routine.State;
import com.b22222.util.Util;
import com.b22222.video.ImageProvider;
import com.b22222.video.VideoPanel;
import com.b22222.video.VideoSource;

public class WebCamMouseTrainer implements ImageProvider {
	
    protected VideoSource source = null;
	protected VideoPanel panel = null;

	private Trainer trainer;
	JButton button;

	public static void main(String[] args) {
		new WebCamMouseTrainer();
	}
	
	public WebCamMouseTrainer() {
		trainer = new Trainer(this);

		Properties properties = Util.loadProperties();
		String deviceLocation = properties.getProperty("videoSource", "vfw:Microsoft WDM Image Capture (Win32):0");

		source = new VideoSource(deviceLocation);
		panel = new VideoPanel(source);
		
		Frame f = new Frame("WebCam Mouse Trainer");
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				source.close();
				System.exit(0);
			}
		});
		button = new JButton("Start Training");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				trainer.start();
				button.setEnabled(false);
			}
		});
		
		JPanel p = new JPanel();
		p.setLayout(new BorderLayout());
		p.add(panel,BorderLayout.CENTER);
		p.add(button,BorderLayout.SOUTH);
		
		f.add("Center", p);
		f.pack();
		f.setSize(new Dimension(640,440));
		f.setVisible(true);

	}
	
	public BufferedImage getImage() {
		return source.getImage();
	}
	
	protected class Trainer extends Thread {
	    
		private ImageProvider provider = null;

	    // used for scaling our images
		int imageScaleX;	
		int imageScaleY;	
		
		// Cache/buffer for two helpfull images
		BufferedImage lastImage;
		BufferedImage thisImage;
		
		// Cache/buffer for two helpfull states
		com.b22222.routine.State lastState;
		com.b22222.routine.State thisState;
		
		// used for comparing our State's
		Comparer comparer;
		
		// used for finding edges
		EdgeDetector edgeDetector;
		double edgeCleanupSD, edgeCleanupAvg, edgeCleanupBase;
		
		// trainer specific
		protected int gridY;
		protected int gridX;
		protected int mouseTrainerDelay;
		protected int mouseTrainerStartDelay;
		protected String mouseTrainerOutput;
		protected boolean renderImageFiles;

		
	    public Trainer(ImageProvider provider) {
			Properties properties = Util.loadProperties();
			gridX = Integer.parseInt(properties.getProperty("mouseTrainerGridX", "16"));
			gridY = Integer.parseInt(properties.getProperty("mouseTrainerGridY", "12"));
			mouseTrainerDelay = Integer.parseInt(properties.getProperty("mouseTrainerDelay", "700"));
			mouseTrainerStartDelay = Integer.parseInt(properties.getProperty("mouseTrainerStartDelay", "9"));
			mouseTrainerOutput = properties.getProperty("mouseTrainerOutput", "c:\\mouse_output\\");

			imageScaleX = Integer.parseInt(properties.getProperty("imageScaleX", "1"));
			imageScaleY = Integer.parseInt(properties.getProperty("imageScaleY", "1"));

			int imageCompareX = Integer.parseInt(properties.getProperty("imageCompareX", "31"));
			int imageCompareY = Integer.parseInt(properties.getProperty("imageCompareY", "23"));
			int imageCompareLeniency = Integer.parseInt(properties.getProperty("imageCompareLeniency", "10"));

			double edgeDetectFlatten = Double.parseDouble(properties.getProperty("edgeDetectFlatten", "-0.1667"));
			double edgeDetectCeling = Double.parseDouble(properties.getProperty("edgeDetectCeling", "0.3333"));

			// setup our comparer for later use.
			comparer = new Comparer(imageCompareX, imageCompareY, imageCompareLeniency);

	 		// setup our edgedetector for later use.
			edgeDetector = new EdgeDetector(edgeDetectFlatten, edgeDetectCeling);

			edgeCleanupSD = Double.parseDouble(properties.getProperty("edgeCleanupSD", "0.5"));
			edgeCleanupAvg = Double.parseDouble(properties.getProperty("edgeCleanupAvg", "1"));
			edgeCleanupBase = Double.parseDouble(properties.getProperty("edgeCleanupBase", "0"));
			
			renderImageFiles = Boolean.valueOf(properties.getProperty("renderImageFiles", "false")).booleanValue();

			this.provider = provider;
	    }
		
		public void run() {
			System.out.println("Please pose for neutral position." +
					"\nTaking neutral picture in " + mouseTrainerStartDelay + " seconds...");
			try { Thread.sleep(mouseTrainerStartDelay * 1000); } catch (InterruptedException ie) { ie.printStackTrace(); }

			lastImage = provider.getImage();
			lastState = new com.b22222.routine.State(lastImage, imageScaleX, imageScaleY); 

			System.out.println("\n\nThe mouse will be automatically moved on your sceen. " +
					"\nAs soon as the mouse has been placed follow it with your pointer. After a short duration, " + 
					"\na picture will be taken and the mouse will move on to the next position." +
					"\nStarting in " + mouseTrainerStartDelay + " seconds...");
			try { Thread.sleep(mouseTrainerStartDelay * 1000); } catch (InterruptedException ie) { ie.printStackTrace(); }
			
			java.awt.GraphicsDevice gd = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
			int screenHeight = gd.getDisplayMode().getHeight();
			int screenWidth = gd.getDisplayMode().getWidth();
			
			// size of the regions on the screen.
			int by = (int)(screenHeight / gridY);
			int bx = (int)(screenWidth / gridX);
			
			// half the size of the regions (we place the mouse in the middle of the regions)
			int by2 = (int)(by / 2);
			int bx2 = (int)(bx / 2);
			
			try {

				Robot r = new Robot(gd);
				
				String outputFolder = mouseTrainerOutput + Util.getTimeStamp();
				File of = new File(outputFolder);
				of.mkdir();
			
				for (int y = 0; y < gridY; y++) {
					for (int x = 0; x < gridX; x++) {
						// move mouse
						int xpos = x * bx + bx2;
						int ypos = y * by + by2;
						r.mouseMove(xpos, ypos);
						r.delay(mouseTrainerDelay);
						
						// snap picture
						thisImage = provider.getImage();
						thisState = new com.b22222.routine.State(thisImage, imageScaleX, imageScaleY); 
						
						
			    		// compare the states and get a variance map
			    		Comparison comparison = comparer.compare(lastState, thisState);
						// return a map with the edges emphasized
						int[][] edge = edgeDetector.process(comparison.getVariance());
						
						// now we try clean up some noise out of the map.
						int average = Util.intArrayAvgNonZero(edge);
						int stdDev = Util.intArrayStdDev(edge);
						int edgeCleanupThreshold = (int)(edgeCleanupBase+((average*edgeCleanupAvg) + (stdDev*edgeCleanupSD)));

						// first lets zero fill any map values that dont cross a certain threshold
						edge = Util.intArrayZeroFillUnderThreshold(edge, edgeCleanupThreshold, 1);
						edge = Util.intArrayRemoveNeighbourless(edge);
						//Util.outputIntArray(edge);
						
						if (renderImageFiles) {
							Graphics2D g = thisImage.createGraphics();
							Util.renderIntArrayToGraphicsDevice(edge, thisImage.getWidth(), thisImage.getHeight(), g);
							Util.renderIntArrayStatsToGraphicsDevice(edge, g);
					    	Util.saveJPG(thisImage, of.getPath() + "\\" + ypos + "_" + xpos + ".jpg");
						}
						// save to training file
						String content = Util.sillyStoreIntArray(edge);
						Util.writeToTextFile(content, of.getPath() + "\\" + ypos + "_" + xpos + ".txt");
						
			    		//lastState = thisState;
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			button.setText("Training Complete.");
		}
		
		
	}
	

	
}


