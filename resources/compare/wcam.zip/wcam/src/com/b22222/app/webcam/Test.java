package com.b22222.app.webcam;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("dfadfadsfasdf");
	}

}
