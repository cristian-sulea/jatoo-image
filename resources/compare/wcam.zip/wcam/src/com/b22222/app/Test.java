package com.b22222.app;


import java.util.Date;
import java.awt.image.BufferedImage;

import com.b22222.routine.Comparer;
import com.b22222.routine.Comparison;
import com.b22222.routine.EdgeDetector;
import com.b22222.routine.State;
import com.b22222.util.Util;

/**
 * This is used as a temporary testing class. uncomment some lines to see the images getting processed.
 * @author PatrickC
 *
 */

public class Test {


	/* create a runable demo thing. */
	public static void main(String[] args) {
		// start profiling
		Date d1 = new Date(); 

		// load the images from file ( could come from other source like webcam)
		BufferedImage b1 = Util.imageToBufferedImage(Util.loadJPG("c:\\work\\pat\\wcam\\test1.jpg")); 
		BufferedImage b2 = Util.imageToBufferedImage(Util.loadJPG("c:\\work\\pat\\wcam\\test2.jpg")); 
		
		// convert the iamges into state maps
		State s1 = new State(b1, 1, 1); 
		State s2 = new State(b2, 1, 1); 
		
		// Create a compare object
//		Comparer ic = new Comparer(186, 138, 1);
		Comparer ic = new Comparer(93, 69, 10);
		// Display some indication of the differences in the image.
		//ic.setDebugMode(1);

/*		// Display image state 2 map
		System.out.println("State 2 Map:");
		Util.outputIntArray(s2.map);*/
		
		// Compare.
		Comparison c = ic.compare(s1, s2);
/*		System.out.println("Match: " + c.match);
		System.out.println("\nVariance Map:");
		Util.outputIntArrayThresholdStdDev(c.variance);
		System.out.println("Variance Avg: " + Util.intArrayAvg(c.variance));
		System.out.println("Variance Avg (excl zero's): " + Util.intArrayAvgNonZero(c.variance));
		System.out.println("Variance StdDev: " + Util.intArrayStdDev(c.variance)); */
		
		// Search for some edges in the latest motion comparison
		EdgeDetector edgeDetector = new EdgeDetector();
		int[][] edge = edgeDetector.process(c.getVariance());

/*		System.out.println("\nEdge Map:");
		Util.outputIntArrayThreshold(edge, 1, 1);
		System.out.println("Edge Avg: " + Util.intArrayAvg(edge));
		System.out.println("Edge Avg (excl zero's): " + Util.intArrayAvgNonZero(edge));
		System.out.println("Edge StdDev: " + Util.intArrayStdDev(edge)); */
		
/*		System.out.println("Edge Map (s2):");
		edge = edgeDetector.process(s2.map);
		Util.outputIntArray(edge);*/
		
		// end profiling
		Date d2 = new Date(); 
		long t = d2.getTime() - d1.getTime();
		System.out.println("Time: " + t + "ms   ("+(1000/t)+" ~fps)");
	}
	


}