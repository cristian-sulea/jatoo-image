package com.b22222.app.webcam;

import java.util.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;

import javax.swing.*;

import com.b22222.routine.Comparer;
import com.b22222.routine.Comparison;
import com.b22222.routine.EdgeDetector;
import com.b22222.routine.State;
import com.b22222.util.Util;
import com.b22222.routine.ImageHelper;
import com.b22222.video.VideoPanel;
import com.b22222.video.VideoSource;
import com.b22222.video.ImageProvider;

/* 
 * App that is used to display information. Usefull for calibrating a settings file - Otherwise just interesting.
 */
public class WebCamState extends Thread implements ImageProvider {

	protected VideoPanel panel;
	protected VideoStatePanel state;
	protected VideoSource source;
	protected ImageHelper image;
	protected Updater updater;
	protected JFrame f;

	public static void main(String[] args) {
		new WebCamState().start();
	}
	
	public WebCamState() {
		Properties properties = Util.loadProperties();
		String deviceLocation = properties.getProperty("videoSource", "vfw:Microsoft WDM Image Capture (Win32):0");

		
		source = new VideoSource(deviceLocation);
		panel = new VideoPanel(source);
		image = new ImageHelper(this);
		state = new VideoStatePanel(image);
		updater = new Updater(state);
		
		f = new JFrame("WebCam State");
		f.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				panel.getVideoSource().close();
				System.exit(0);
			}
		});
		
		JButton baseI = new JButton("Set Base Image");
		baseI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				image.setBaseImage();
			}
		});
		JButton thisI = new JButton("Start Compare...");
		thisI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				updater.start();
			}
		});
		
		
		JPanel p = new JPanel();
        GridBagLayout gridbag = new GridBagLayout();
        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.BOTH;
        c.weightx = 0.5;
        c.weighty = 0;
        c.gridwidth = 1;
        c.gridheight = 1;

        c.gridx = 0;
        c.gridy = 0;
        gridbag.setConstraints(baseI, c);
        p.add(baseI);

        c.gridx = 1;
        gridbag.setConstraints(thisI, c);
        p.add(thisI);

        c.weighty = 1;
        c.gridx = 0;
        c.gridy = 1;
        gridbag.setConstraints(panel, c);
        p.add(panel);
        
        c.gridx = 1;
        gridbag.setConstraints(state, c);
        p.add(state);

		p.setLayout(gridbag);
		f.add("Center", p);
		
		f.pack();
		f.setSize(new Dimension(1300,580));
		f.setVisible(true);	
	}
	
	public BufferedImage getImage() {
		return source.getImage();
	}
	
}

class Updater extends Thread {
	
	VideoStatePanel com;
	
	public Updater(VideoStatePanel jc) {
		com = jc;
	}
	
	public synchronized void run() {
		while (true) {
			com.setFlag(false);
			com.updateImage();
			com.setFlag(true);
			com.repaint();
			try {
				sleep(5);
			} catch (Exception e) { e.printStackTrace(); }
		}
	}
	
}

class VideoStatePanel extends JPanel {

    private static final long serialVersionUID = 55318008;

    protected boolean flag;
    protected ImageProvider provider;
    protected BufferedImage image;
    
	public VideoStatePanel(ImageProvider provider) {
		this.provider = provider;
		setPreferredSize(new java.awt.Dimension(570, 460));
		this.setBackground(java.awt.Color.CYAN);
		flag = false;
	}
	
	public synchronized void updateImage() {
		image = provider.getImage();
	}
	
	public synchronized void paint(Graphics g) {
		//super.paint(g);
		if (this.flag) {
			g.drawImage(image, 0, 0, null);
		}
	}
	
	public synchronized void setFlag(boolean value) {
		flag = value;
	}
	
	public void setProvider(ImageProvider provider) {
		this.provider = provider;
	}
	
}
