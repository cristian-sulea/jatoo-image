package com.b22222.io;

import java.io.*;

import org.joone.io.*;
import org.joone.log.*;
import org.joone.exception.JooneRuntimeException;
import org.joone.engine.NetErrorManager;

import com.b22222.util.*;

/** Allows data to be presented to the network from a WebCamMouseTrainer output location. */
public class MousePositionSampleInputSynapse extends StreamInputSynapse {
	
    /** The logger used to log errors and warnings. */
    private static final ILogger log = LoggerFactory.getLogger(MousePositionSampleInputSynapse.class);
    private static final long serialVersionUID = 55318008;
    
    /** The name of the folder to extract information from. */
    private String inputLocation = "";
    private transient File inputFile;
    
    public MousePositionSampleInputSynapse() {
        super();
    }
    
    /*private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        super.readObjectBase(in);
        if (in.getClass().getName().indexOf("xstream") == -1) {
            fileName = (String) in.readObject();
        }
        if ((fileName != null) && (fileName.length() > 0))
            inputFile = new File(fileName);
    }
    
    private void writeObject(ObjectOutputStream out) throws IOException {
        super.writeObjectBase(out);
        if (out.getClass().getName().indexOf("xstream") == -1) {
            out.writeObject(fileName);
        }
    }*/
    
    protected void initInputStream() throws JooneRuntimeException {
      /*  if ((inputLocation != null) && (!inputLocation.equals(new String("")))) {
            try {
                inputFile = new File(inputLocation);
                File[] files = inputFile.listFiles();
                String content = "";
                for (int i = 0; i < files.length; i++) {
                	// for every text data file in the directory loads its data onto a new row in the content string.
                	if (files[i].getName().indexOf(".txt") > -1) {
	                	content += ("320" + "200") + "\n";
                	}
                }
                System.out.println("*---------------------------------------------*\n" + content);
                super.setTokens(new StreamInputTokenizer(new StringReader(content), 10000000));
            } catch (IOException ioe) {
                String error = "IOException in "+getName()+". Message is : ";
                log.warn(error + ioe.getMessage());
                if ( getMonitor() != null)
                    new NetErrorManager(getMonitor(),error+ioe.getMessage());
            }
        }*/
    }
    
    public File getInputFile() {
        return inputFile;
    }
    
    public void setInputFile(File inputFile) {
        if (inputFile != null) {
            if (!inputLocation.equals(inputFile.getAbsolutePath())) {
                this.inputFile = inputFile;
                inputLocation = inputFile.getAbsolutePath();
                this.resetInput();
                super.setTokens(null);
            }
        } else {
            this.inputFile = inputFile;
            inputLocation = "";
            this.resetInput();
            super.setTokens(null);
        }
    }
    
}