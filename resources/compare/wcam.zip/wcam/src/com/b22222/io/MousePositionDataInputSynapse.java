package com.b22222.io;

import java.io.*;

import org.joone.io.*;
import org.joone.exception.JooneRuntimeException;

import com.b22222.util.*;

/** Allows data to be presented to the network from a WebCamMouseTrainer output location. */
public class MousePositionDataInputSynapse extends StreamInputSynapse {
	
    private static final long serialVersionUID = 55318008;
    
    /** The name of the folder to extract information from. */
    private String inputLocation = "";
    private transient File inputFile;
    
    private int width; // width of the maps
    private int height; // width of the maps
    
    public MousePositionDataInputSynapse(int width, int height) {
        super();
        this.width = width;
        this.height = height;
    }
    
    /*private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        super.readObjectBase(in);
        if (in.getClass().getName().indexOf("xstream") == -1) {
            fileName = (String) in.readObject();
        }
        if ((fileName != null) && (fileName.length() > 0))
            inputFile = new File(fileName);
    }
    
    private void writeObject(ObjectOutputStream out) throws IOException {
        super.writeObjectBase(out);
        if (out.getClass().getName().indexOf("xstream") == -1) {
            out.writeObject(fileName);
        }
    }*/
    
    protected void initInputStream() throws JooneRuntimeException {
        if ((inputLocation != null) && (!inputLocation.equals(new String("")))) {
            try {
                inputFile = new File(inputLocation);
                File[] files = inputFile.listFiles();
                String content = "";
                for (int i = 0; i < files.length; i++) {
                	// for every text data file in the directory loads its data onto a new row in the content string.
                	if (files[i].getName().indexOf(".txt") > -1) {
	                	int[][] m = Util.sillyRetrieveIntArray(Util.readTextFromFile(files[i].getCanonicalPath()).trim(), width, height);
	                	String line = "";
	                	for (int q = 0; q < m.length; q++) {
	                		for (int w = 0; w < m.length; w++) {
	                			line += (line.equals("") ? "" : ";") + m[q][w];
	                		}
	                	}
	                	content += line + "\n";
                	}
                }
                System.out.println("InputData:\n" + content);
                super.setTokens(new StreamInputTokenizer(new StringReader(content)));
            } catch (IOException ioe) {
            	ioe.printStackTrace();
            }
        }
    }
    
    public File getInputFile() {
        return inputFile;
    }
    
    public void setInputFile(File inputFile) {
        if (inputFile != null) {
            if (!inputLocation.equals(inputFile.getAbsolutePath())) {
                this.inputFile = inputFile;
                inputLocation = inputFile.getAbsolutePath();
                this.resetInput();
                super.setTokens(null);
            }
        } else {
            this.inputFile = inputFile;
            inputLocation = "";
            this.resetInput();
            super.setTokens(null);
        }
    }
    
}