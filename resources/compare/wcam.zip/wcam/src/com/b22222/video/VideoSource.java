package com.b22222.video;

import javax.media.*;
import javax.media.format.*;
import javax.media.util.*;
import javax.media.control.*;

import com.b22222.util.Util;

import java.awt.image.*;
 
public class VideoSource implements ImageProvider {

	protected Player player = null;

	protected CaptureDeviceInfo captureDeviceInfo = null;
	protected MediaLocator mediaLocator = null;

	protected FrameGrabbingControl frameGrabber;
	protected VideoFormat vf = null;

	protected String videoDevice;
	
	public VideoSource(String videoDevice) {
		this.videoDevice = videoDevice;

		captureDeviceInfo = CaptureDeviceManager.getDevice(videoDevice);
		javax.media.Format[] f = captureDeviceInfo.getFormats();
		for(int i = 0; i < f.length; i++)
			System.out.println(f[i].getEncoding());
		
		mediaLocator = captureDeviceInfo.getLocator();
		
		try {
			player = Manager.createRealizedPlayer(mediaLocator);
			player.start();
		} catch (Exception e) { 
			e.printStackTrace(); 
		}

		frameGrabber = (FrameGrabbingControl)player.getControl("javax.media.control.FrameGrabbingControl");
	}

	public java.awt.Component getVisualComponent() {
		return player.getVisualComponent();
	}
	
	public void close() {
		player.close();
		player.deallocate();
	}
  
 
	public BufferedImage getFrame() {
		// Grab a frame
		Buffer buf = frameGrabber.grabFrame();

		// Convert it to an image
		BufferToImage btoi = new BufferToImage((VideoFormat)buf.getFormat());
		return Util.imageToBufferedImage(btoi.createImage(buf));
	}

	public BufferedImage getImage() {
		return getFrame(); 
	}
	

}
