package com.b22222.video;

import java.awt.*;
 
public class VideoPanel extends Panel {

    private static final long serialVersionUID = 55318008;

    protected VideoSource source = null;

	public VideoPanel(VideoSource videoSource) {
		super();
		setVideoSource(videoSource);
	}
	
	public VideoPanel() {
		super();
	}
	
	public void setVideoSource(VideoSource videoSource) {
		source = videoSource;
		setLayout(new BorderLayout());
		try {
			Component comp;
			if ((comp = source.getVisualComponent()) != null)
				add(comp,BorderLayout.NORTH);
		} catch (Exception e) { 
			e.printStackTrace(); 
		}
	}
 
	protected void finalize() throws Throwable {
		super.finalize();
		source.close();
	}
	
	public VideoSource getVideoSource() {
		return source;
	}
  
}
