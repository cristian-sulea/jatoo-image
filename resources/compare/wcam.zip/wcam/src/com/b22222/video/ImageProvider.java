package com.b22222.video;

import java.awt.image.BufferedImage;;

public interface ImageProvider {

	public BufferedImage getImage();
	
}
