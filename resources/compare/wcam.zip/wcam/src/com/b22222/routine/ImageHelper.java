package com.b22222.routine;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.Properties;

import com.b22222.util.Util;
import com.b22222.video.ImageProvider;

public class ImageHelper implements ImageProvider {
	
	// used for scaling our images
	int imageScaleX;	
	int imageScaleY;	
	
	// Cache/buffer for two helpfull images
	BufferedImage baseImage;
	BufferedImage thisImage;
	
	// Cache/buffer for two helpfull states
	com.b22222.routine.State baseState;
	com.b22222.routine.State thisState;
	
	// used for comparing our State's
	Comparer comparer;
	
	// used for finding edges
	EdgeDetector edgeDetector;
	double edgeCleanupSD, edgeCleanupAvg, edgeCleanupBase;
	double intWeightRenderFactor;
	boolean edgeCleanupLonelies;
	
	ImageProvider provider;
	
	public ImageHelper(ImageProvider provider) {
		this.provider = provider;

		Properties properties = Util.loadProperties();

		imageScaleX = Integer.parseInt(properties.getProperty("imageScaleX", "1"));
		imageScaleY = Integer.parseInt(properties.getProperty("imageScaleY", "1"));

		int imageCompareX = Integer.parseInt(properties.getProperty("imageCompareX", "160"));
		int imageCompareY = Integer.parseInt(properties.getProperty("imageCompareY", "120"));
		int imageCompareLeniency = Integer.parseInt(properties.getProperty("imageCompareLeniency", "10"));

		double edgeDetectFlatten = Double.parseDouble(properties.getProperty("edgeDetectFlatten", "-0.1667"));
		double edgeDetectCeling = Double.parseDouble(properties.getProperty("edgeDetectCeling", "0.3333"));

		// setup our comparer for later use.
		comparer = new Comparer(imageCompareX, imageCompareY, imageCompareLeniency);

 		// setup our edgedetector for later use.
		edgeDetector = new EdgeDetector(edgeDetectFlatten, edgeDetectCeling);

		edgeCleanupSD = Double.parseDouble(properties.getProperty("edgeCleanupSD", "0.5"));
		edgeCleanupAvg = Double.parseDouble(properties.getProperty("edgeCleanupAvg", "1"));
		edgeCleanupBase = Double.parseDouble(properties.getProperty("edgeCleanupBase", "0"));

		intWeightRenderFactor = Double.parseDouble(properties.getProperty("intWeightRenderFactor", "1"));
		edgeCleanupLonelies = Boolean.parseBoolean(properties.getProperty("edgeCleanupLonelies", "false"));
	}
	
	public BufferedImage getBaseImage() {
		return baseImage;
	}
	
	public com.b22222.routine.State getBaseState() {
		return baseState;
	}
	
	public void setBaseImage() {
		baseImage = provider.getImage();
		baseState = new com.b22222.routine.State(baseImage, imageScaleX, imageScaleY); 
	}
	
    public void setThisImage() {
    	thisImage = provider.getImage();
		thisState = new com.b22222.routine.State(thisImage, imageScaleX, imageScaleY); 
		// compare the states and get a variance map
		Comparison comparison = comparer.compare(baseState, thisState);
		// return a map with the edges emphasized
		int[][] edge = edgeDetector.process(comparison.getVariance());
		
		// now we try clean up some noise out of the map.
		int average = Util.intArrayAvgNonZero(edge);
		int stdDev = Util.intArrayStdDev(edge);
		int edgeCleanupThreshold = (int)(edgeCleanupBase+((average*edgeCleanupAvg) + (stdDev*edgeCleanupSD)));

		// first lets zero fill any map values that dont cross a certain threshold
		edge = Util.intArrayZeroFillUnderThreshold(edge, edgeCleanupThreshold, 1);
		if (edgeCleanupLonelies) edge = Util.intArrayRemoveNeighbourless(edge);
		
		Graphics2D g = thisImage.createGraphics();
		Util.renderIntArrayToGraphicsDevice(edge, thisImage.getWidth(), thisImage.getHeight(), g, intWeightRenderFactor);
		Util.renderIntArrayStatsToGraphicsDevice(edge, g);
		Util.renderIntArrayCOGToGraphicsDevice(edge, thisImage.getWidth(), thisImage.getHeight(), g, intWeightRenderFactor);
		
		//baseState = thisState;  // uncomment this if you want a motion detection vibe.
    }
	
	public BufferedImage getThisImage() {
		return thisImage;
	}
	
	public com.b22222.routine.State getThisState() {
		return thisState;
	}
	
	public BufferedImage getImage() {
		setThisImage();
		return getThisImage();
	}
	
	

}
