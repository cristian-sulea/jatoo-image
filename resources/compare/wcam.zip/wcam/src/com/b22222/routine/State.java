package com.b22222.routine;

import java.awt.image.*;

import com.b22222.util.Util;

public class State {

	public int[][] map;
	public int width;
	public int height;
	public int average;
	
	public State(BufferedImage img, int resX, int resY) {
		// setup brightness map
		width = (int)(img.getWidth() / resX);
		height = (int)(img.getHeight() / resY);
		map = new int[height][width];
		
		// build map and stats
		average = 0;
		int ta = 0;
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				ta = (int)(100*Util.getBrightnessAtPoint(img, x * resX, y * resY));
				//int ta1 = (int)(100*Util.getBrightnessAtPoint(img, x * resX, y * resY));
				//int ta2 = (int)(100*Util.getBrightnessAtPoint(img, x * resX +1, y * resY +1));
				//int ta3 = (int)(100*Util.getBrightnessAtPoint(img, x * resX +2, y * resY +2));
				//ta = (int)((ta1 + ta2 + ta3) / 3);
				map[y][x] = ta;
				average += ta;
			}
		}
		average = (int)(average / (width * height));
	}


	// future constructors here might interpret different kinds of data maps....
	
}
